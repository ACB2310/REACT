import { useEffect, useRef } from 'react'
import { Map as MapaMapLibre, NavigationControl, setWorkerUrl } from 'maplibre-gl'
import urlWorkerMapLibre from 'maplibre-gl/dist/maplibre-gl-worker.mjs?url'
import 'maplibre-gl/dist/maplibre-gl.css'
import './MapaBase.css'

// Estilos de OpenFreeMap: gratuitos y sin llave
const ESTILO_CLARO = 'https://tiles.openfreemap.org/styles/liberty'
const ESTILO_OSCURO = 'https://tiles.openfreemap.org/styles/dark'

// Centro aproximado de México en [longitud, latitud]
const CENTRO_MEXICO = [-102.5, 23.6]

// Mapa base de MapLibre. En cuanto carga el estilo, entrega el mapa con `alCargar(mapa)`
// para que otras capas (como CapaSismos) puedan dibujar encima.
// Si el estilo no se puede descargar, avisa con `alFallar()`.
function MapaBase({ alCargar, alFallar }) {
  const contenedorRef = useRef(null)

  // Se guarda la última versión de `alCargar` en una ref para no
  // volver a crear el mapa cada vez que el componente padre se redibuja
  const alCargarRef = useRef(alCargar)
  const alFallarRef = useRef(alFallar)
  useEffect(() => {
    alCargarRef.current = alCargar
    alFallarRef.current = alFallar
  }, [alCargar, alFallar])

  // Crea el mapa una sola vez y lo elimina al salir de la pantalla.
  // En StrictMode React monta, desmonta y vuelve a montar: por eso es importante `remove()`.
  useEffect(() => {
    // MapLibre procesa las teselas y el GeoJSON en un "worker" (un hilo aparte).
    // Vite no lo encuentra solo, así que le decimos dónde está; con `?url` Vite
    // lo sirve en desarrollo y lo copia a dist/ al compilar.
    setWorkerUrl(urlWorkerMapLibre)

    // El estilo del mapa sigue el modo claro u oscuro del sistema
    const consultaTema = window.matchMedia?.('(prefers-color-scheme: dark)')
    const mapa = new MapaMapLibre({
      container: contenedorRef.current,
      style: consultaTema?.matches ? ESTILO_OSCURO : ESTILO_CLARO,
      center: CENTRO_MEXICO,
      zoom: 4,
    })
    // La atribución de OpenFreeMap y OpenStreetMap la agrega MapLibre por defecto
    mapa.addControl(new NavigationControl({ showCompass: false }), 'top-right')
    // Se usa 'style.load' y no 'load': 'load' espera a que bajen todas las teselas,
    // y con mala señal los sismos tardarían mucho en aparecer
    let estiloCargado = false
    mapa.on('style.load', () => {
      estiloCargado = true
      alCargarRef.current?.(mapa)
    })
    // Antes de cargar el estilo, un error significa que no hay mapa base.
    // Después, los errores son de teselas sueltas y MapLibre los reintenta solo.
    mapa.on('error', () => {
      if (!estiloCargado) alFallarRef.current?.()
    })

    // Si el usuario cambia el tema con la app abierta, se carga el otro estilo.
    // diff: false fuerza una carga completa para que se dispare 'style.load'
    // y CapaSismos vuelva a dibujar los sismos.
    function alCambiarTema(evento) {
      mapa.setStyle(evento.matches ? ESTILO_OSCURO : ESTILO_CLARO, { diff: false })
    }
    consultaTema?.addEventListener('change', alCambiarTema)

    return () => {
      consultaTema?.removeEventListener('change', alCambiarTema)
      mapa.remove()
    }
  }, [])

  return <div ref={contenedorRef} className="mapa-base" />
}

export default MapaBase
